/*
 * OutputController.cpp
 *
 *  Created on: May 9, 2016
 *      Author: Shannalotte
 */

#include "OutputController.h"

OutputController::OutputController() {
	// TODO Auto-generated constructor stub

}

OutputController::~OutputController() {
	// TODO Auto-generated destructor stub
}

void OutputController::setData(std::string s){
	// TODO
}
